# AT·OM - Infrastructure Invisible

**PROPRIÉTÉ EXCLUSIVE DE JONATHAN EMMANUEL RODRIGUE**
**TOUS DROITS RÉSERVÉS - BREVET EN COURS - 2025**

---

## Déploiement DigitalOcean App Platform

### Structure (Flat)
```
/
├── index.html      # Interface principale
├── style.css       # Design Canon AT·OM
├── app.js          # Logique application
├── manifest.json   # Configuration PWA
├── icon-192.png    # Icône 192x192
├── icon-512.png    # Icône 512x512
└── README.md       # Ce fichier
```

### Instructions

1. **Créer un repo GitHub privé**
   - Nom suggéré: `AT-OM-DEPLOY`

2. **Upload des fichiers**
   - Copier tous les fichiers à la racine du repo

3. **DigitalOcean App Platform**
   - New App > GitHub
   - Sélectionner le repo
   - Type: Static Site
   - Source Directory: `/` (vide)
   - Build Command: (laisser vide)
   - Output Directory: `/`

4. **Configuration API**
   - Dans `app.js`, remplacer `URL_A_REMPLIR` par l'URL de votre API

---

## Caractéristiques

- **PWA**: Fonctionne en plein écran sur iPad
- **Canon AT·OM**: Design noir/or/cobalt
- **350 Agents**: L'Essaim complet
- **Modules**: Génie, Alchimie, Flux, Santé
- **Protocol-999**: Brise-Circuit (triple tap sur fréquence)

---

## Icônes Requises

Générer les icônes avec votre logo:
- `icon-192.png` (192x192 pixels)
- `icon-512.png` (512x512 pixels)

---

© 2025 Jonathan Emmanuel Rodrigue - Tous droits réservés
